#
# Copyright Amazon AWS DeepLens, 2017
#

import os
import greengrasssdk
from threading import Timer
import time
import awscam
import cv2
from threading import Thread
from random import randint

# Creating a greengrass core sdk client
client = greengrasssdk.client('iot-data')

# The information exchanged between IoT and clould has 
# a topic and a message body.
# This is the topic that this code uses to send messages to cloud
iotTopic = '$aws/things/{}/infer'.format(os.environ['AWS_IOT_THING_NAME'])
ret, frame = awscam.getLastFrame()
ret,jpeg = cv2.imencode('.jpg', frame) 
Write_To_FIFO = True
class FIFO_Thread(Thread):
    def __init__(self):
        ''' Constructor. '''
        Thread.__init__(self)
 
    def run(self):
        fifo_path = "/tmp/results.mjpeg"
        if not os.path.exists(fifo_path):
            os.mkfifo(fifo_path)
        f = open(fifo_path,'w')
        #client.publish(topic=iotTopic, payload="Opened Pipe")
        while Write_To_FIFO:
            try:
                f.write(jpeg.tobytes())
            except IOError as e:
                continue  

def greengrass_infinite_infer_run():
    try:
        modelPath = "/opt/awscam/artifacts/mxnet_deploy_ssd_resnet50_512_FP16_FUSED.xml"
        modelType = "ssd"
        input_width = 512
        input_height = 512
        max_threshold = 0.50
        zip_codes = [60606, 90001, 10001, 98101, 80014, 73301, 48127, 63101]
        outMap = { 1: 'nike', 2: 'adidas' }
        results_thread = FIFO_Thread()
        results_thread.start()
        # Send a starting message to IoT console
        #client.publish(topic=iotTopic, payload="Object detection starts now")

        # Load model to GPU (use {"GPU": 0} for CPU)
        mcfg = {"GPU": 1}
        model = awscam.Model(modelPath, mcfg)
        #client.publish(topic=iotTopic, payload="Model loaded")
        ret, frame = awscam.getLastFrame()
        if ret == False:
            raise Exception("Failed to get frame from the stream")
            
        # yscale = float(frame.shape[0]/input_height)
        # xscale = float(frame.shape[1]/input_width)
        yscale = float(frame.shape[0]/406)
        xscale = float(frame.shape[1]/618)

        doInfer = True
        
        numFrames = 0;
        while doInfer:
            numFrames += 1;
            
            # Get a frame from the video stream
            ret, frame = awscam.getLastFrame()
            # Raise an exception if failing to get a frame
            if ret == False:
                raise Exception("Failed to get frame from the stream")

            # Resize frame to fit model input requirement
            frameResize = cv2.resize(frame, (input_width, input_height))

            # Run model inference on the resized frame
            inferOutput = model.doInference(frameResize)

            if numFrames >= 1:
                numFrames = 0;
                parsed_results = model.parseResult(modelType, inferOutput)['ssd']
                label = ''
                for obj in parsed_results:
                    if obj['prob'] > max_threshold:
                        print(obj)
                        xmin = int( xscale * obj['xmin'] ) + int((obj['xmin'] - input_width/2) + input_width/2)
                        ymin = int( yscale * obj['ymin'] )
                        xmax = int( xscale * obj['xmax'] ) + int((obj['xmax'] - input_width/2) + input_width/2)
                        ymax = int( yscale * obj['ymax'] )
                        cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (255, 165, 20), 4)
                        label += '{},{:.2f}'.format(outMap[obj['label']], obj['prob'] )
                        label_show = "{}:    {:.2f}%".format(outMap[obj['label']], obj['prob']*100 )
                        cv2.putText(frame, label_show, (xmin, ymin-15),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 165, 20), 4)
                        label += ','
                        label += str(zip_codes[randint(0, 7)])
                        label += ','
                        label += time.strftime("%Y-%m-%d %H:%M:%S")
                        label += '\n'
                        
                if len(parsed_results) > 0:
                    client.publish(topic=iotTopic, payload = label)
                    
                global jpeg
                ret,jpeg = cv2.imencode('.jpg', frame)
            
    except Exception as e:
        msg = "Test failed: " + str(e)
        client.publish(topic=iotTopic, payload=msg)

    # Asynchronously schedule this function to be run again in 15 seconds
    Timer(15, greengrass_infinite_infer_run).start()


# Execute the function above
greengrass_infinite_infer_run()


# This is a dummy handler and will not be invoked
# Instead the code above will be executed in an infinite loop for our example
def function_handler(event, context):
    return